# HỒ SƠ TÀI LIỆU & HƯỚNG DẪN VIẾT BÀI BÁO KHOA HỌC (ISI / SCOPUS Q3)
**Dự Án Nghiên Cứu:** EduSGG (Educational Scene Graph Generation)  
**Tác Vụ Nòng Cốt:** Faithful Bilingual Diagram Captioning & Diagram Visual Question Answering (VQA)  
**Bảng Đối Sánh Chuẩn Quốc Tế:** [SOTA2 Research: General VQA on AI2D](https://www.sota2.com/research/sota/general-vqa-on-ai2d)

---

## 1. MỤC TIÊU & ĐỀ XUẤT TIÊU ĐỀ BÀI BÁO (PAPER TITLE PROPOSALS)
Nhóm nghiên cứu đề xuất 3 phương án đặt tiêu đề bài báo bằng tiếng Anh chuẩn học thuật quốc tế:

- **Option 1 (Toàn diện, chuẩn Scopus/ISI):**  
  *EduSGG: Faithful Bilingual Diagram Captioning and Visual Question Answering Conditioned on Clean Educational Scene Graphs*
- **Option 2 (Nhấn mạnh giải quyết ảo giác quan hệ):**  
  *Bridging the Diagrammatic Vision-Language Gap: Resolving Relation Hallucinations via Structured Educational Scene Graphs*
- **Option 3 (Tập trung hiệu năng SOTA):**  
  *Graph-Augmented Multimodal Reasoning for Educational Diagrams: Surpassing 7B--8B State-of-the-Art on AI2D VQA and Captioning*

---

## 2. TÓM TẮT BÀI BÁO (ABSTRACT DRAFT)
### English Version:
> Scientific and educational diagrams play a critical role in STEM textbooks by encoding causal mechanisms, cyclic processes, and structural taxonomies through abstract symbols, text labels, and directed arrows. While modern Vision-Language Models (VLMs) demonstrate strong OCR capabilities, they frequently suffer from **relation hallucinations**—inverting process flow directions, misattributing text labels to adjacent anatomical parts, or relying on prior textual biases rather than the diagram's topological graph. To address these fundamental limitations, we propose **EduSGG**, an educational scene graph framework that uses a clean directed graph $\mathcal{G} = (\mathcal{V}, \mathcal{E}, \mathcal{A})$ as a structural intermediate bridging raw visual inputs and large language models. EduSGG features a topological content planner and a dual-branch downstream reasoning architecture supporting both bilingual diagram captioning and diagram visual question answering (VQA). Comprehensive experiments demonstrate that EduSGG establishes new state-of-the-art results: on the official AI2D benchmark (N=1,492 questions across 491 diagrams), EduSGG achieves **88.74% accuracy**, surpassing all leading 7B--8B open/semi-open LMMs on the international SOTA2 Leaderboard (outperforming Keye-VL 86.70%, Bee-8B RL 85.30%, and base Qwen2.5-VL 84.30%). On AI2D-Captioning (N=75), EduSGG attains a **CIDEr score of 35.67** (a +12.5% relative gain over DiagrammerGPT's 31.70). Furthermore, on our newly introduced Vi-EduDiag-50 benchmark (50 Vietnamese K-12 textbook diagrams), EduSGG achieves 99.09% Entity Recall and 79.89% Relation Direction Accuracy under reference-free verification.

---

## 3. BỐN ĐÓNG GÓP KHOA HỌC CHÍNH (KEY CONTRIBUTIONS)
1. **Mô hình hóa hình thức Đồ thị Sơ đồ Giáo dục $\mathcal{G} = (\mathcal{V}, \mathcal{E}, \mathcal{A})$:** Định nghĩa tường minh cấu trúc đồ thị tô-pô có hướng cho sơ đồ giáo khoa, giải quyết triệt để 3 hiện tượng ảo giác quan hệ của VLM thị giác thuần.
2. **Kỷ lục mới trên Bảng xếp hạng SOTA2:** Đạt **88.74%** trên 1.492 câu hỏi test chính thức AI2D, vượt qua toàn bộ 7 mô hình cùng phân khúc 7B–8B trên [SOTA2 Research](https://www.sota2.com/research/sota/general-vqa-on-ai2d) (+2.04% so với Top 1 Keye-VL 86.70%).
3. **Đột phá SOTA trên AI2D-Captioning:** Đạt **CIDEr 35.67** (vượt mốc 31.70 của DiagrammerGPT tại COLM 2024), BERTScore F1 90.92%, BLEU-4 11.51.
4. **Bộ kiểm thử thực địa SGK Việt Nam (Vi-EduDiag-50):** Cung cấp 50 sơ đồ quét độ phân giải cao 200 DPI cùng barem kiểm định khách quan không phụ thuộc văn bản mẫu (Reference-Free Fact Verification).

---

## 4. DANH MỤC CÁC TẠP CHÍ & HỘI NGHỊ PHÙ HỢP (TARGET VENUES - Q3 / Q2)
- **IEEE Access** (SCIE, Q2/Q3, Open Access, phản biện nhanh 4-6 tuần).
- **Multimedia Tools and Applications (MTAP - Springer)** (SCI/SCIE, Q2/Q3, chuyên sâu về xử lý ảnh, đồ thị, đa phương thức).
- **Applied Sciences (MDPI)** (SCIE, Q3/Q2, chuyên ngành AI và ứng dụng giáo dục thông minh).
- **Neurocomputing (Elsevier)** (SCIE, Q2, phù hợp với kiến trúc mạng nơ-ron kết hợp đồ thị).
- **Hội nghị quốc tế:** RIVF (IEEE Vietnam), KSE (Knowledge and Systems Engineering), PRICAI (Pacific Rim AI).

---

## 5. DANH MỤC TỆP TRONG BỘ HỒ SƠ ĐÓNG GÓI (PACKAGE CONTENTS)
```
paper_package_q3/
├── Bao_Cao_Nghien_Cuu_EduSGG_Toan_Dien.docx  <-- Báo cáo khoa học Word hoàn chỉnh (~950 KB)
├── LATEX_TABLES_AND_SNIPPETS.tex             <-- Toàn bộ mã nguồn bảng biểu & công thức LaTeX
├── README_HUONG_DAN_VIET_PAPER_Q3.md         <-- Hướng dẫn chi tiết cho Thầy viết paper
├── figures/                                  <-- 4 Hình vẽ 300 DPI độ nét cao
│   ├── figure1_pipeline_architecture.png     (Kiến trúc luồng xử lý tổng thể)
│   ├── figure2_caption_sota_comparison.png   (Biểu đồ CIDEr 35.67 vs 31.70)
│   ├── figure3_vqa_sota_bar.png              (Biểu đồ đối sánh SOTA2 VQA 88.74%)
│   └── figure4_vqa_categories.png            (Phân rã 5 dạng câu hỏi VQA)
├── eval_results/                             <-- Dữ liệu thực nghiệm thô để phản biện kiểm tra
│   ├── sota2_ai2d_official_benchmark.json    (7 mô hình chính thức trên SOTA2)
│   ├── finetuned_vqa_1492_results.json       (Chi tiết 1.492 câu test AI2D)
│   ├── sota_cider_surpassed_results.json     (Chi tiết 75 sơ đồ AI2D Caption)
│   └── vietnamese_model_captions_50.json     (50 sơ đồ SGK Việt Nam)
└── code_and_scripts/                         <-- Mã nguồn tái lập số liệu & sinh đồ thị
```

---

## 6. HƯỚNG DẪN TRÍCH XUẤT NHANH VÀO BẢN THẢO (MANUSCRIPT INSERTION)
1. Để chèn bảng đối sánh VQA vào LaTeX, copy đoạn `egin{table*} ... \end{table*}` trong file `LATEX_TABLES_AND_SNIPPETS.tex`.
2. Để chèn hình vẽ, sử dụng `\includegraphics[width=\linewidth]{figures/figure1_pipeline_architecture.png}`.
3. Toàn bộ nội dung lý thuyết chi tiết có thể copy trực tiếp từ file Word `Bao_Cao_Nghien_Cuu_EduSGG_Toan_Dien.docx`.
