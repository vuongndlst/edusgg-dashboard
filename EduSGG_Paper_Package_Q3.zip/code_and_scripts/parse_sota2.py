# scripts/parse_sota2.py
import re
import json

with open('scratch/sota2_ai2d.html', 'r', encoding='utf-8') as f:
    html = f.read()

match = re.search(r'\"rows\":\s*(\[.*?\]),\s*\"total\":\s*7', html)
if match:
    rows_json = match.group(1)
    fixed = rows_json.replace('\\"', '"')
    parsed_rows = json.loads(fixed)
    with open('scratch/sota2_rows.json', 'w', encoding='utf-8') as out:
        json.dump(parsed_rows, out, ensure_ascii=False, indent=2)
    print(f'Successfully parsed and saved {len(parsed_rows)} rows to scratch/sota2_rows.json!')
    for i, r in enumerate(parsed_rows):
        print(f"Rank {i+1}: {r}")
else:
    print("Pattern not matched!")
